<?php
    session_start();
	include('../mysqlcon/mysqlConnect.php');
	//creating database and table
	mysql_query("CREATE DATABASE IF NOT EXISTS SitemakerDB",$con);
	mysql_select_db("SitemakerDB",$con);

$sql="CREATE TABLE IF NOT EXISTS tbl_comment (
  comment_id int(11) NOT NULL,
  parent_comment_id int(11) NOT NULL,
  comment varchar(200) NOT NULL,
  comment_sender_name varchar(40) NOT NULL,
  page_id varchar(100) NOT NULL,
  date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

mysql_query($sql,$con);
 //Indexes for dumped tables

//Indexes for table `tbl_comment`
$sql="ALTER TABLE `tbl_comment`
  ADD PRIMARY KEY (`comment_id`);";

mysql_query($sql,$con);  

// AUTO_INCREMENT for dumped tables

// AUTO_INCREMENT for table `tbl_comment`
$sql="ALTER TABLE `tbl_comment`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT;";

mysql_query($sql,$con);  
?>