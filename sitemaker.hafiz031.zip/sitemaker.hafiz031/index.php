
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<?php
 include('includes/header.php')
?>

<title>SiteMaker | Home</title>
<div class="container">
	
</div>
<aside id="fh5co-hero" class="js-fullheight">
	<div class="flexslider js-fullheight">
		<ul class="slides">
	   	<li style="background-image: url(images/long_way_to_go.jpg);">
	   		<div class="overlay-gradient"></div>
	   		<div class="container">
	   			<div class="col-md-10 col-md-offset-1 text-center js-fullheight slider-text">
	   				<div class="slider-text-inner">
	   					<h2>A Long Way To Go?</h2>
	   					<p><a href="#" class="btn btn-primary btn-lg">Don't worry! Join Today and Start Learining:)</a></p>
	   				</div>
	   			</div>
	   		</div>
	   	</li>
	   	<li style="background-image: url(images/geek.jpg);">
	   		<div class="container">
	   			<div class="col-md-10 col-md-offset-1 text-center js-fullheight slider-text">
	   				<div class="slider-text-inner">
	   					<h2 style="color: #27E1EC";>Have Some Idea to Share With the World?</h2>
	   					<p><a href="#" class="btn btn-primary btn-lg">Well! Join to Blog Today!!</a></p>
	   				</div>
	   			</div>
	   		</div>
	   	</li>
	   	<li style="background-image: url(images/help.jpg);">
	   		<div class="container">
	   			<div class="col-md-10 col-md-offset-1 text-center js-fullheight slider-text">
	   				<div class="slider-text-inner">
	   					<h2>Need Help?</h2>
	   					<p><a href="#" class="btn btn-primary btn-lg">We Are Always Here :D</a></p>
	   				</div>
	   			</div>
	   		</div>
	   	</li>
	  	</ul>
  	</div>
</aside>

<?php
 include ('includes/footer.php');
?>