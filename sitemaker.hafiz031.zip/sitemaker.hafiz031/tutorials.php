<?php
 include('includes/header.php')
?>
<style type="text/css">
    body{
        /*background-image: url('images/long_way_to_go.jpg');*/
        background-color: #fff;
    }
</style>
<div id="fh5co-work-section" class="fh5co-light-grey-section">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center fh5co-heading animate-box">
                <h2>LEARN ON</h2>
                <p>Learn on topics related to HTML,CSS,PHP and more... </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 animate-box">
                <a href="HTML/homeHTML.php" class="item-grid text-center">
                    <div class="image" style="background-image: url(images/HTML.jpg)"></div>
                    <div class="v-align">
                        <div class="v-align-middle">
                            <h3 class="title">HTML</h3>
                            <h5 class="category">Hypertext Markup Language</h5>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 animate-box">
                <a href="#" class="item-grid text-center">
                    <div class="image" style="background-image: url(images/CSS.jpg)"></div>
                    <div class="v-align">
                        <div class="v-align-middle">
                            <h3 class="title">CSS</h3>
                            <h5 class="category">Cascading Style Sheets</h5>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 animate-box">
                <a href="#" class="item-grid text-center">
                    <div class="image" style="background-image: url(images/PHP.jpg)"></div>
                    <div class="v-align">
                        <div class="v-align-middle">
                            <h3 class="title">PHP</h3>
                            <h5 class="category">Hypertext Preprocessor</h5>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 animate-box">
                <a href="#" class="item-grid text-center">
                    <div class="image" style="background-image: url(images/JS.jpg)"></div>
                    <div class="v-align">
                        <div class="v-align-middle">
                            <h3 class="title">JavaScript and AJAX</h3>
                            <h5 class="category">JavaScript and Asynchronous JavaScript and XML</h5>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 animate-box">
                <a href="#" class="item-grid text-center">
                    <div class="image" style="background-image: url(images/MSQL.png);background-repeat: no-repeat;"></div>
                    <div class="v-align">
                        <div class="v-align-middle">
                            <h3 class="title">MySQL</h3>
                            <h5 class="category">An open source RDBMS based on SQL (Standard Query Language)</h5>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 animate-box">
                <a href="books.php" class="item-grid text-center">
                    <div class="image" style="background-image: url(images/Books.jpg);background-size: 100%;height: 48%; background-repeat: no-repeat;"></div>
                    <div class="v-align">
                        <div class="v-align-middle">
                            <h3 class="title">Book Reference</h3>
                            <h5 class="category">Assists you in better learning</h5>
                        </div>
                    </div>
                </a>
            </div>
<?php
 include ('includes/footer.php');
?>