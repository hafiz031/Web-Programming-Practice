<?php
 include('includes/header.php')
?>
<style type="text/css">
    body{
        /*background-image: url('images/long_way_to_go.jpg');*/
         background-color: #555555;
    }
    #fh5co-work-section .item-grid {
    width: 50%;
    float: left;
    position: relative;
    background: #fff;
    margin-bottom: 50px;
    -webkit-box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.11);
    -moz-box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.11);
    box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.11);
    -webkit-transition: 0.3s;
    -o-transition: 0.3s;
    transition: 0.3s;
    top: 2px;
    }
    #fh5co-work-section .item-grid .image {
    height: 200px;
    overflow: hidden;
    margin-bottom: 20px;
    background-size: cover;
    background-position: center center;
    }
</style>
<div id="fh5co-work-section" class="fh5co-light-grey-section">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center fh5co-heading animate-box">
                <h2 style="color: #fff;">Manage User Profiles</h2>
                <p style="color: #fff;">(This Page is Accessible by Admin Only)</p>
            </div>
             <!--search box-->
            <form class="form-wrapper">
            <input type="text" id="search" placeholder="Search for user..." required>
            <input type="submit" value="go" id="submit">
            </form>
            <!--end of search box-->
            <!--AJAX Code Will Go Here-->

            <!--End of AJAX Code-->
        </div>
        <div class="row">
        <?php
            include('mysqlcon/mysqlConnect.php');
            mysql_select_db("SitemakerDB",$con);
            $sql = "SELECT Username,PPDirectory FROM  registration_info";
            $result = mysql_query($sql);
            while ($row = mysql_fetch_assoc($result)) {
                 $uname=$row[Username];
                 $pp=substr($row[PPDirectory],3);
        ?>
                <div class="col-md-4 animate-box">
                <a href="profile.php" class="item-grid text-center">
                    <div class="image" style="background-image: url(<?php echo $pp;?>)"></div>
                    <div class="v-align">
                        <div class="v-align-middle">
                            <h3 class="title"><?php echo $uname; ?></h3>
                        </div>
                    </div>
                </a>
                </div>
        <?php                
            }
        ?>
        </div>
    </div>
</div>
<div id="fh5co-testimony-section">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center fh5co-heading animate-box">
                <h2>Clients Feedback</h2>
                <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-offset-0 to-animate">
                <div class="wrap-testimony animate-box">
                    <div class="owl-carousel-fullwidth">
                        <div class="item">
                            <div class="testimony-slide active text-center">
                                <figure>
                                    <img src="images/person1.jpg" alt="user">
                                </figure>
                                <blockquote>
                                    <p>"Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean."</p>
                                </blockquote>
                                <span>Athan Smith, via <a href="#" class="twitter">Twitter</a></span>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-slide active text-center">
                                <figure>
                                    <img src="images/person2.jpg" alt="user">
                                </figure>
                                <blockquote>
                                    <p>"Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean."</p>
                                </blockquote>
                                <span>Nathalie Kosley, via <a href="#" class="twitter">Twitter</a></span>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-slide active text-center">
                                <figure>
                                    <img src="images/person3.jpg" alt="user">
                                </figure>
                                <blockquote>
                                    <p>"Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean."</p>
                                </blockquote>
                                <span>Yanna Kuzuki, via <a href="#" class="twitter">Twitter</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="fh5co-blog-section" class="fh5co-light-grey-section">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center fh5co-heading animate-box">
                <h2>Recent from Blog</h2>
                <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-sm-6 animate-box">
                <a href="#" class="item-grid">
                    <div class="image" style="background-image: url(images/image_1.jpg)"></div>
                    <div class="v-align">
                        <div class="v-align-middle">
                            <h3 class="title">We Create Mobile App</h3>
                            <h5 class="date"><span>June 23, 2016</span> | <span>4 Comments</span></h5>
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove.</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-6 col-sm-6 animate-box">
                <a href="#" class="item-grid">
                    <div class="image" style="background-image: url(images/image_2.jpg)"></div>
                    <div class="v-align">
                        <div class="v-align-middle">
                            <h3 class="title">Geographical App</h3>
                            <h5 class="date"><span>June 22, 2016</span> | <span>10 Comments</span></h5>
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove.</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-12 text-center animate-box">
                <p><a href="#" class="btn btn-primary with-arrow">View More Post <i class="icon-arrow-right"></i></a></p>
            </div>
        </div>
    </div>
</div>
<div id="fh5co-pricing-section">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center fh5co-heading animate-box">
                <h2>Pricing</h2>
                <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. </p>
            </div>
        </div>
        <div class="row">
            <div class="pricing">
                <div class="col-md-3 animate-box">
                    <div class="price-box">
                        <h2 class="pricing-plan">Starter</h2>
                        <div class="price"><sup class="currency">$</sup>9<small>/month</small></div>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. </p>
                        <a href="#" class="btn btn-select-plan btn-sm">Select Plan</a>
                    </div>
                </div>

                <div class="col-md-3 animate-box">
                    <div class="price-box">
                        <h2 class="pricing-plan">Basic</h2>
                        <div class="price"><sup class="currency">$</sup>27<small>/month</small></div>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. </p>
                        <a href="#" class="btn btn-select-plan btn-sm">Select Plan</a>
                    </div>
                </div>

                <div class="col-md-3 animate-box">
                    <div class="price-box popular">
                        <h2 class="pricing-plan pricing-plan-offer">Pro <span>Best Offer</span></h2>
                        <div class="price"><sup class="currency">$</sup>74<small>/month</small></div>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. </p>
                        <a href="#" class="btn btn-select-plan btn-sm">Select Plan</a>
                    </div>
                </div>

                <div class="col-md-3 animate-box">
                    <div class="price-box">
                        <h2 class="pricing-plan">Unlimited</h2>
                        <div class="price"><sup class="currency">$</sup>140<small>/month</small></div>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. </p>
                        <a href="#" class="btn btn-select-plan btn-sm">Select Plan</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="fh5co-cta" style="background-image: url(images/slide_2.jpg);">
    <div class="overlay"></div>
    <div class="container">
        <div class="col-md-12 text-center animate-box">
            <h3>We Try To Update The Site Everyday</h3>
            <p><a href="#" class="btn btn-primary btn-outline with-arrow">Get started now! <i class="icon-arrow-right"></i></a></p>
        </div>
    </div>
</div>

<?php
 include ('includes/footer.php');
?>