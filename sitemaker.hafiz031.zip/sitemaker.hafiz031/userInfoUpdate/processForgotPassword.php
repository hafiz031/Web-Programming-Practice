<?php
session_start();
if(isset($_POST['emailForgot'])&&!(isset($_POST['username'])&&isset($_POST['password'])))
{
include('../mysqlcon/mysqlConnect.php');
mysql_select_db("SitemakerDB",$con);
$_SESSION['ra']=$_POST['emailForgot'];
$query="SELECT * FROM registration_info WHERE Email ='".$_POST['emailForgot']."'";
$result=mysql_query($query);
if(mysql_num_rows($result)<=0)
{
	echo "<script type='text/javascript'>alert('Sorry! We could not find your email in the database')</script>";
	echo "<script type='text/javascript'>window.open('../login.php','_self')</script>";
	exit();
}
$row=mysql_fetch_array($result);
$_SESSION['mailBody']=base64_decode($row['Password']);
include '../sendingMail.php';
echo "<script type='text/javascript'>window.open('../login.php','_self')</script>";
exit();
}
?>