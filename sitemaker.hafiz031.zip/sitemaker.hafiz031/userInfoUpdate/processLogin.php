<?php
session_start();
$connect = mysql_connect("localhost", "root", "hafiz031");
mysql_select_db("sitemakerDB");
if(isset($_POST["reg_user"]))
{  
 if(!empty($_POST["username"]) && !empty($_POST["password"]))
 {
  $name =$_POST["username"];
  $password = $_POST["password"];
  //FOR ADMIN CONTROL
  if($name=="admin"&&$password=="*aAaA123aaaaa"){
  	$_SESSION['isAdmin']=1;
  }
  else
  {
  	$_SESSION['isAdmin']=0;	
  }
//cookie start
  if(isset($_POST['remember'])){
  	$cookie_name="member_login";
  	$cookie_value=$_POST['username'];
  	setcookie($cookie_name,$cookie_value,time()+(30),"/");//60 second
  	$cookie_name="member_password";
  	$cookie_value=$_POST['password'];
  	setcookie($cookie_name,$cookie_value,time()+(30),"/");//60 second
  }
  // $sql = "SELECT * from  registration_info where Username = '" . $name . "' AND Password = '" . base64_encode($password) . "'";  
  // $result = mysql_query($sql);  
  // $user = mysql_fetch_array($result);  
  // if($user)   
  // {  
  //  if(!empty($_POST["remember"]))   
  //  {  
  //   setcookie ("member_login",$name,time()+ (60));  
  //   setcookie ("member_password",$password,time()+ (60));
  //   $_SESSION["un"] = $name;
  //   $_SESSION["pw"]=$pass;//added
  //  }  
  //  else  
  //  {  
  //   if(isset($_COOKIE["member_login"]))   
  //   {  
  //    setcookie ("member_login","");  
  //   }  
  //   if(isset($_COOKIE["member_password"]))   
  //   {  
  //    setcookie ("member_password","");  
  //   }  
  //  }  
   // header("location:home.php"); 
  }  
  
} 




	//cookies code end
	if(isset($_POST['username'])&&isset($_POST['password']))
	//if(1)
	{
		//echo "string";
		include('../mysqlcon/mysqlConnect.php');
		mysql_select_db("SitemakerDB",$con);
		//$uname=mysqli_real_escape_string($con,trim($_POST['username']));
	    //$pass=mysqli_real_escape_string($con,trim($_POST['password']));
	   	$uname=$_POST['username'];
	   	$pass=base64_encode($_POST['password']);
		//$uname="hafiz031";
		//$pass="hafiz031";
		if(empty($uname)||empty($pass))//if login info is empty redirect to login page 
		{
			echo "<script type='text/javascript'>alert('Please enter your login information')</script>";
			echo "<script type='text/javascript'>window.open('../login.php','_self')</script>";
			exit();
		}
		else
		{
			$sql="SELECT * FROM registration_info WHERE Username='$uname' OR Email='$uname'";
			//$resultCheck=$result;
			$result=mysql_query($sql);
			$resultCheck=mysql_num_rows($result);
			if($resultCheck<1)//if no rows selected
			{
				echo "<script type='text/javascript'>alert('Invalid login information')</script>";
				echo "<script type='text/javascript'>window.open('../login.php','_self')</script>";
				exit();
			}
			else
			{
				if($row=mysql_fetch_assoc($result))
				{

					//echo $uname;
					//echo $pass;

					$query="SELECT * FROM registration_info WHERE Username='".$uname."' AND Password='".$pass."'";
    				$result=mysql_query($query);
    				$row=mysql_fetch_array($result);

    				//var_dump($_POST['username']);
    				//var_dump($_POST['password']);

                    //echo $row['Username']; why it is not getting printed?!
					if(!($row['Password']==$pass))//if the input password does not match with the database-stored password
					{
						echo "<script type='text/javascript'>alert('Invalid username or password')</script>";
						echo "<script type='text/javascript'>window.open('../login.php','_self')</script>";
						exit();
					}
					else if($row['Password']==$pass)//if login successful store login informations into session variables
					{
						//echo "accessed into session";
						//echo $_COOKIE['member_login'];
						//echo $_COOKIE['member_password'];
						$_SESSION['un']=$row['Username'];
						//$_SESSION['un']=$_COOKIE['member_login'];
						$_SESSION['fn']=$row['FirstName'];
						$_SESSION['ln']=$row['LastName'];
						$_SESSION['em']=$row['Email'];
						$_SESSION['pw']=$row['Password'];
						//$_SESSION['pw']=$_COOKIE['member_password'];
						$_SESSION['pp']=$row['PPDirectory'];
					    echo "<script type='text/javascript'>window.open('../index.php','_self')</script>";
					}
				}
			}
		}
	}
?>	
<!--hafiz031-->
