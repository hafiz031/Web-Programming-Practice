<?php
	session_start();	
	include('../mysqlcon/mysqlConnect.php');

	$currentUname=$_SESSION['un'];//collecting current username from session variable
    $newUname=$_POST[username];//newly inputed username from form
	$fanme=$_POST[firstname];
	$lname=$_POST[lastname];
	$em=$_POST[email];
	$passOld=base64_encode($_POST[oldpassword]);
	$passNew=base64_encode($_POST[newpassword]);

	//first confirming the updated username hasn't any duplicate 
	mysql_select_db("SitemakerDB",$con);//selecting database
	$query="SELECT * FROM registration_info WHERE Username='".$currentUname."'";
    $result=mysql_query($query);
    $row=mysql_fetch_array($result);

    //if new password field is kept empty the current pasword will be taken
    if($passNew=='')
    {
    	$passNew=$passOld;
    }

    if($newUname=='')
    {
    	echo "<script type='text/javascript'>alert('You must enter a valid username')</script>";
    	echo "<script type='text/javascript'>window.open('../profile.php','_self')</script>";
    	exit();
    }
    /*NOT NECESSERY BECAUSE OTHER FIELDS CAN BE UPDATED FOR THE SAME USERNAME
    //if the username already exists then fetch to update page again
    if($row['Username']==$newUname)
    {
    	echo "<script type='text/javascript'>alert('Username already exists! Please choose a different one')</script>";
    	echo "<script type='text/javascript'>window.open('profile.php','_self')</script>";
    	exit();
    }*/
    
    //deleting account
    if($row['Password']==$passOld&&isset($_POST[dacc]))
    {
        $query="DELETE FROM registration_info WHERE Username='".$currentUname."'";
        //echo "HEllo";
        mysql_query($query);
        echo "<script type='text/javascript'>window.open('../logout.php','_self')</script>";
        exit();
    }
    if($row['Password']!=$passOld)
    {
    	echo "<script type='text/javascript'>alert('Please enter correct current password')</script>";
    	echo "<script type='text/javascript'>window.open('../profile.php','_self')</script>";
    	exit();
    }

    /*UNNECESSERY
    //if old and new passwords don't match 
	if($passNew!=$passOld)
    {
    	echo "<script type='text/javascript'>alert('Passwords don't match)</script>";
    	echo "<script type='text/javascript'>window.open('profile.php','_self')</script>";
    	exit();
    }    
	*/

    //Uploading Image 
     $file=$_FILES['file'];//gets all the information about the file to be uploaded (we named the file as file)
    //print_r($file);
    $fileName=$_FILES['file']['name'];
    $fileTmpName=$_FILES['file']['tmp_name'];
    $fileSize=$_FILES['file']['size'];
    $fileError=$_FILES['file']['error'];
    $fileType=$_FILES['file']['type'];

    //which file I want to allow to be uploaded
    $fileExt=explode('.',$fileName);//take whatwvwe after '.'
    $fileActualExt=strtolower(end($fileExt));//for management purpose as uploaded file can be with different cases of extensions of same type...e.g, JPG and jpg
    $allowed=array('jpg','jpeg','png','gif','pdf');

    if(in_array($fileActualExt,$allowed))
    {
        if($fileError==0)
        {
            if($fileSize<1000000)
            {
                $fileNameNew=uniqid('',true).".".$fileActualExt;//to prevent replacing the older file with the newer file if the file name is the same as it generates the unique name based on time in microsecond
                $fileDestination='../uploads/profilePics/'.$fileNameNew;
                //Or use entire destination like this
                //$fileDestination='C:\Program Files\XAMPP\xampp\htdocs\sitemaker.hafiz031\uploads\profilePics\ '.$fileNameNew;//Notice: an space is put between \ and ' to prevent it from taking in different meaning
                move_uploaded_file($fileTmpName,$fileDestination);//(fileName,dst) from temp location to actual location
                //header("Location:index.php?uploadsuccess");//this will bring us to the frontpage after we are done (?uploadsuccess just a hint on what's going on..not a mandatory part)
            }
            else
            {
                echo "Your file is too big";
            }
        }
        else
        {
            echo "There was an error uploading your file";
        }
    }
    else
    {
        $fileDestination=$_SESSION['pp'];
    }
    //endOfImageUploadingCode

	//if everthing so far is ok then update
	$sql="UPDATE registration_info SET FirstName = '$_POST[firstname]' WHERE Username='$currentUname'";
	if (!mysql_query($sql,$con)){die('Error: ' . mysql_error());}
	$sql="UPDATE registration_info SET LastName = '$_POST[lastname]' WHERE Username='$currentUname'";
	if (!mysql_query($sql,$con)){die('Error: ' . mysql_error());}
	$sql="UPDATE registration_info SET Email = '$_POST[email]' WHERE Username='$currentUname'";
	if (!mysql_query($sql,$con)){die('Error: ' . mysql_error());}
	$sql="UPDATE registration_info SET Password = '$passNew' WHERE Username='$currentUname'";
	if (!mysql_query($sql,$con)){die('Error: ' . mysql_error());}
	$sql="UPDATE registration_info SET Username = '$_POST[username]' WHERE Username='$currentUname'";//updating the username at last of all because it is the primary key and we couldn't update the other fields if it was altered before
	if (!mysql_query($sql,$con)){die('Error: ' . mysql_error());}
    //updating new image location
    $sql="UPDATE registration_info SET PPDirectory = '$fileDestination' WHERE Username='$currentUname'";
    if (!mysql_query($sql,$con)){die('Error: ' . mysql_error());}
 	//finally update session variables
	$_SESSION['un']=$newUname;
	$_SESSION['fn']=$fanme;
	$_SESSION['ln']=$lname;
	$_SESSION['em']=$em;
	$_SESSION['pw']=base64_decode($passNew);
    $_SESSION['pp']=$fileDestination;

   	echo "<script type='text/javascript'>alert('Your informations are successfully updated.')</script>";
   	echo "<script type='text/javascript'>window.open('../profile.php','_self')</script>";

	mysql_close($con);
?>
<!--hafiz031-->