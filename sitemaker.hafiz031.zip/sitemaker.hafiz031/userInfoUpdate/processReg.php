<?php
    session_start();
	include('../mysqlcon/mysqlConnect.php');
	//creating database and table
	mysql_query("CREATE DATABASE IF NOT EXISTS SitemakerDB",$con);
	mysql_select_db("SitemakerDB",$con);
	$sql="CREATE TABLE IF NOT EXISTS registration_info
	(
		Username varchar(30),
		FirstName varchar(30),
		LastName varchar(30),
		Email varchar(60),
		Password varchar(100),
        PPDirectory varchar(500)
    )";
    mysql_query($sql,$con);//creating database

    //inserting user-registration informations 

    $uname=$_POST[username];
    $fname=$_POST[firstname];
    $lname=$_POST[lastname];
    $em=$_POST[email];
    $pass=base64_encode($_POST[password]);//password encoded
    $cpas=base64_encode($_POST[cpassword]);//password encoded;
    //First checking if same username alredy exists
    //$query="SELECT * FROM registration_info WHERE FirstName='".$fname."' AND LastName='".$lname."' AND Email='".$em."'";
    $query="SELECT * FROM registration_info WHERE Username='".$uname."'";
    $result=mysql_query($query);
    echo $result['Username'];
    $row=mysql_fetch_array($result);

    //echo $row['Username'];
    //echo $uname;
    // if($pass!=$cpass)
    // {
    //     echo "<script type='text/javascript'>alert('passwords don't match)</script>";
    //     echo "<script type='text/javascript'>window.open('../register.php','_self')</script>";

    // }
    if($row['Username']==$uname)//if the username already exists then fetch to registration page again
    {
    	echo "<script type='text/javascript'>alert('Username already exists! Please choose a different one')</script>";
    	echo "<script type='text/javascript'>window.open('../register.php','_self')</script>";

    }
    else
    {
    	if($uname==null||$fname==null||$lname==null||$em==null||$pass==null)//if the form is incomplete don't proceed
    	{
    		echo "<script type='text/javascript'>alert('Form Incomplete!')</script>";
    		echo "<script type='text/javascript'>window.open('../register.php','_self')</script>";
    	}
        //Uploading Image 
        $file=$_FILES['file'];//gets all the information about the file to be uploaded (we named the file as file)
        //print_r($file);
        $fileName=$_FILES['file']['name'];
        $fileTmpName=$_FILES['file']['tmp_name'];
        $fileSize=$_FILES['file']['size'];
        $fileError=$_FILES['file']['error'];
        $fileType=$_FILES['file']['type'];

        //which file I want to allow to be uploaded
        $fileExt=explode('.',$fileName);//take whatwvwe after '.'
        $fileActualExt=strtolower(end($fileExt));//for management purpose as uploaded file can be with different cases of extensions of same type...e.g, JPG and jpg
        $allowed=array('jpg','jpeg','png','gif','pdf');

        if(in_array($fileActualExt,$allowed))
        {
            if($fileError==0)
            {
                if($fileSize<1000000)
                {
                    $fileNameNew=uniqid('',true).".".$fileActualExt;//to prevent replacing the older file with the newer file if the file name is the same as it generates the unique name based on time in microsecond
                    $fileDestination='../uploads/profilePics/'.$fileNameNew;
                    //Or use entire destination like this
                    //$fileDestination='C:\Program Files\XAMPP\xampp\htdocs\sitemaker.hafiz031\uploads\profilePics\ '.$fileNameNew;//Notice: an space is put between \ and ' to prevent it from taking in different meaning
                    move_uploaded_file($fileTmpName,$fileDestination);//(fileName,dst) from temp location to actual location
                    //header("Location:index.php?uploadsuccess");//this will bring us to the frontpage after we are done (?uploadsuccess just a hint on what's going on..not a mandatory part)
                }
                else
                {
                    echo "Your file is too big";
                }
            }
            else
            {
                echo "There was an error uploading your file";
            }
        }
        else
        {
            echo "You cannot upload files of this type";
        }
        //endOfImageUploadingCode

	    $sql="INSERT INTO registration_info(Username,FirstName,LastName,Email,Password,PPDirectory) VALUES('$uname','$fname','$lname','$em','$pass','$fileDestination')";
	    if(!mysql_query($sql,$con))
	    {
	    	$ck=0;
	    	die('Error: '.mysql_error());
	    }
	    else
	    {
	    	echo "<script type='text/javascript'>alert('Thanks for registration!')</script>";
	    	$ck=1;
	    }
	    if($ck)//if ck==1 i.e registration succssful auto-open homepage
	    {
            //auto sign in
                $_SESSION['un']=$uname;
                $_SESSION['fn']=$fname;
                $_SESSION['ln']=$lname;
                $_SESSION['em']=$em;
                $_SESSION['pw']=$pass;
                $_SESSION['pp']=$fileDestination;
                echo "<script type='text/javascript'>window.open('../index.php','_self')</script>";
            //end of auto sign in code
	    }
    }
    

    //closing
    mysql_close($con);
?>