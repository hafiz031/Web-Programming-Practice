<?php
session_start();
 $_SESSION['currentPage']="HTML.overview";
 
 ?>
 <link rel="stylesheet" type="text/css" href="style.css">
<?php
include('header.php');
?>

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Overview</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/blog-post.css" rel="stylesheet">

  </head>

  <body>
    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <!-- Post Content Column -->
        <div class="col-lg-8">

          <!-- Title -->
          <h1 class="mt-4">Overview</h1>

          <!-- Author -->
        

          <hr>

          <!-- Date/Time -->

          <hr>

          <!-- Preview Image -->
          <img class="img-fluid rounded" src="Capture.JPG" alt="">

          <hr>

          <!-- Post Content -->
          <p class="lead">HTML stands for Hypertext Markup Language, and it is the most widely used language to write Web Pages.

    Hypertext refers to the way in which Web pages (HTML documents) are linked together. Thus, the link available on a webpage is called Hypertext.

    As its name suggests, HTML is a Markup Language which means you use HTML to simply "mark-up" a text document with tags that tell a Web browser how to structure it to display.

Originally, HTML was developed with the intent of defining the structure of documents like headings, paragraphs, lists, and so forth to facilitate the sharing of scientific information between researchers.

Now, HTML is being widely used to format web pages with the help of different tags available in HTML language.</p>

          
          <hr>
        <!-- Comment -->
          


        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4">

          <!-- Side Widget -->
          <div class="card my-4">
            <h5 class="card-header">Concept</h5>
            <div class="card-body">
              Hypertext Markup Language, a standardized system for tagging text files to achieve font, colour, graphic, and hyperlink effects on World Wide Web pages.
            </div>
          </div>

        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
   

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
<?php
$_SESSION['currentPage']="overview";
include ('comment.php');
include('C:\Program Files\XAMPP\xampp\htdocs\sitemaker.hafiz031\includes\footer.php'); 
?>
