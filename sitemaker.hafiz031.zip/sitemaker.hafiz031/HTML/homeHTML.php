<?php
 session_start();
 $_SESSION['currentPage']="HTML.overview";
 
 ?>
 <link rel="stylesheet" type="text/css" href="style.css">
 <?php
include('header.php');
?>

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Blog Home - Start Bootstrap Template</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/blog-home.css" rel="stylesheet">

  </head>

  <body>

  

    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-8">

          <h1 class="my-4">Overview on HTML
            <small>let's start learning HTML</small>
          </h1>

          <!-- Blog Post -->
          <div class="card mb-4">
            <img class="card-img-top" src="Capture.JPG" alt="Card image cap">
            <div class="card-body">
              <h2 class="card-title">Overview</h2>
              <a href="overview.php" class="btn btn-primary">Click to read &rarr;</a>
            </div>
          </div>

            <h1 class="my-4">Attribute on HTML
          </h1>
          <!-- Blog Post -->
          <div class="card mb-4">
            <img class="card-img-top" src="HTML-attribute.jpg" alt="Card image cap">
            <div class="card-body">
              <h2 class="card-title">Attributes on HTML</h2>
              <a href="attribute.php" class="btn btn-primary">Click to read &rarr;</a>
            </div>
          </div>


          <!-- Blog Post -->
            <h1 class="my-4">Styles on HTML
            
          </h1>
          <div class="card mb-4">
            <img class="card-img-top" src="img1.JPG" height="300" alt="Card image cap">
            <div class="card-body">
              <h2 class="card-title">Styles on HTML</h2>
              <a href="stylesHTML.php" class="btn btn-primary">Click to read &rarr;</a>
            </div>
          </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4">

          <!-- Categories Widget -->

          </div>

          <!-- Side Widget -->
          <div class="card my-4">
           
            </div>
          </div>

        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
<?php
include('footer.php'); 
?>
