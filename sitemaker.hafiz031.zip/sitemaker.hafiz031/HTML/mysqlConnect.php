<?php
$con = mysql_connect('localhost', 'root', 'hafiz031');
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
mysql_select_db('my_db', $con);
$sql="set names 'utf8'";
mysql_query($sql);
mysql_query('SET CHARACTER SET utf8')or die('charset problem:'.mysql_error());
mysql_query("SET SESSION collation_connection ='utf8_general_ci'") or die('collation problem:'.mysql_error());
?>