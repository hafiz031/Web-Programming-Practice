<?php
 session_start();
 include('header.php')
?>
<style type="text/css">
    body{
        /*background-image: url('images/long_way_to_go.jpg');*/
         background-color: #555555;
    }
    #fh5co-work-section .item-grid {
    width: 20%;
    float: left;
    position: relative;
    background: #fff;
    margin-bottom: 50px;
    margin-left: 40px;
    -webkit-box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.11);
    -moz-box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.11);
    box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.11);
    -webkit-transition: 0.3s;
    -o-transition: 0.3s;
    transition: 0.3s;
    top: 2px;
    }
    #fh5co-work-section .item-grid .image {
    height: 200px;
    overflow: hidden;
    margin-bottom: 20px;
    background-size: cover;
    background-position: center center;
    }
</style>


<script>
function showResult(str)
{
    if (str.length==0) 
    { 
        return;//but nothing is shown until the page is refreshed when the search keyword is removed
    }
    if (window.XMLHttpRequest) 
    {
        xmlhttp=new XMLHttpRequest();
    }

    else 
    { 
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange=function() 
    {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
            document.getElementById("replace").innerHTML=xmlhttp.responseText;
        }
    }

    xmlhttp.open("GET","processSearch.php?q="+str,true);
    xmlhttp.send();

}
</script>



  <!--Default one initially to be shown-->
<div id="fh5co-work-section" class="fh5co-light-grey-section">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center fh5co-heading animate-box">
                <h2 style="color: #fff;">Manage User Profiles</h2>
                <p style="color: #fff;">(This Page is Accessible by Admin Only)</p>
            </div>

            </head>
            <body>


            <form class="form-wrapper">
            <input type="text" id="search" placeholder="Search for topic" onkeyup="showResult(this.value)" required>
            <input type="submit" value="go" id="submit">
            </form>

            </body>
            <!--end of search box-->
            <!--AJAX Code Will Go Here-->
            <!--End of AJAX Code-->
 <div class="row" id="replace">


        <?php
            include('mysqlConnect.php');
            mysql_select_db("SitemakerDB",$con); 
            
            $query = "SELECT * FROM `registration_info` WHERE ";
            $result = mysql_query($query);
            while ($row = mysql_fetch_array($result)) 
            {
            $uname=$row[Username];
            //echo $uname;
            $pp=substr($row[PPDirectory],3);
        ?>
                <a href="profile.php" class="item-grid text-center">
                    <div class="image" style="background-image: url(<?php echo $pp;?>)"></div>
                    <div class="v-align">
                        <div class="v-align-middle">
                            <h3 class="title"><?php echo $uname; ?></h3>
                        </div>
                    </div>
                </a>

        <?php                
            }
        ?>      
</div>
</div>
<?php
 include ('footer.php');
?>