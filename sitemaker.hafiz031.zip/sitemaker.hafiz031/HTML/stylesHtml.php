<?php
session_start();
 $_SESSION['currentPage']="HTML.overview";
 
 ?>
 <link rel="stylesheet" type="text/css" href="style.css">
<?php
include('header.php');
?>

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Overview</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/blog-post.css" rel="stylesheet">

  </head>

  <body>
    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <!-- Post Content Column -->
        <div class="col-lg-8">

          <!-- Title -->
          <h1 class="mt-4">HTML Attributes</h1>

          <!-- Author -->
        

          <hr>

          <!-- Date/Time -->

          <hr>

          <!-- Preview Image -->
          

          <hr>
         <h2>The HTML Style Attribute</h2>
<p>Setting the style of an HTML element, can be done with the <code class="w3-codespan">style</code> attribute.</p>
<p>The HTML <code class="w3-codespan">style</code> attribute has the following <strong>syntax</strong>:</p>
          <!-- Post Content -->
          
HTML links are defined with the anchor tag. The link address is specified in the href attribute:

        <!-- Comment -->
            
<img  src="Capture4.JPG" alt="">


<h2>HTML Background Color</h2>
<p>The <code class="w3-codespan">background-color</code> property defines the background color 
for an HTML element.</p>
<p>This example sets the background color for a page to powderblue:</p>

<img  src="Capture5.JPG" alt="">



<h2>HTML Text Size</h2>
<p>The <code class="w3-codespan">font-size</code> property defines the text size for 
an HTML element:</p>

<img  src="Capture6.JPG" alt="">

        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4">

    
          <!-- Side Widget -->
          <div class="card my-4">
            <h5 class="card-header">Concept</h5>
            <div class="card-body">
              Setting the style of an HTML element, can be done with the style attribute. The HTML style attribute has the following syntax: <tagname style="property:value;"> The property is a CSS property. The value is a CSS value.
            </div>
          </div>

        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
   

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
<?php
$_SESSION['currentPage']="styleHTML";
include ('comment.php');
include('footer.php'); 
?>
