<?php
session_start();
//include('../includes/header.php');
include('mysqlConnect.php');
mysql_select_db("SitemakerDB",$con);

$searchName = urldecode(filter_var(trim($_GET['q'])));


$sql = "SELECT * FROM `registration_info` WHERE `Username` LIKE '%{$searchName}%'";
$result = mysql_query($sql);
?>

<style type="text/css">
    body{
        /*background-image: url('images/long_way_to_go.jpg');*/
         background-color: #555555;
    }
    #fh5co-work-section .item-grid {
    width: 20%;
    float: left;
    position: relative;
    background: #fff;
    margin-bottom: 50px;
    margin-left: 40px;
    -webkit-box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.11);
    -moz-box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.11);
    box-shadow: 0px 1px 2px 0px rgba(0, 0, 0, 0.11);
    -webkit-transition: 0.3s;
    -o-transition: 0.3s;
    transition: 0.3s;
    top: 2px;
    }
    #fh5co-work-section .item-grid .image {
    height: 200px;
    overflow: hidden;
    margin-bottom: 20px;
    background-size: cover;
    background-position: center center;
    }
</style>

<?php
while ($row = mysql_fetch_array($result)) 
            {
            $uname=$row[Username];
            $pp=substr($row[PPDirectory],3);
        ?>
                <a href="profile.php" class="item-grid text-center">
                    <div class="image" style="background-image: url(<?php echo $pp;?>)"></div>
                    <div class="v-align">
                        <div class="v-align-middle">
                            <h3 class="title"><?php echo $uname; ?></h3>
                        </div>

                    </div>
                </a>
    <?php                
    }
?>      
</div>
<?php
// include ('../includes/footer.php');
?>