<?php
 include('header.php');
?>
<li style="background-image: url(../images/long_way_to_go.jpg);
    height: 700px;
    background-size: cover;
    background-size: 100% 100%;
    background-repeat: no-repeat;
    background-position: right top;
    background-attachment: fixed;"
>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap Login &amp; Register Templates</title>
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Favicon and touch icons -->
    <link rel="shortcut icon" href="assets/ico/favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

    
            <div class="form-box" style="width: 35%;">
                <div class="form-top">
                    <div class="form-top-left">
                        <h3>Sign in now</h3>
                        <p>Fill in the form below to get instant access:</p>
                    </div>
                    <div class="form-top-right">
                        <i class="fa fa-pencil"></i>
                    </div>
                </div>
                <div class="form-bottom">
                    <form role="form" action="userInfoUpdate/processLogin.php" method="post" class="registration-form">
                        <div class="form-group">
                            <label class="sr-only" for="form-first-name">Username</label>
                            <input name="username" placeholder="Username" type="text" value="<?php if(isset($_COOKIE["member_login"])) { echo $_COOKIE["member_login"]; } ?>" class="grad" style="width: 100%;"/>  
                             <!-- <input type="text" placeholder="Username" name="username" class="grad" style="width: 100%;"> -->
                        </div>
                         <div class="form-group">
                            <label class="sr-only">Password</label>
                               <!-- <input type="password" placeholder="Password" name="password" style="width: 100%;"> -->
                               <input name="password" type="password" placeholder="Password" value="<?php if(isset($_COOKIE["member_password"])) { echo $_COOKIE["member_password"]; } ?>" style="width: 100%;" />  
                        </div>
                              <input type="checkbox" name="remember" <?php if(isset($_COOKIE["member_login"])) { ?> checked <?php } ?> />  <label for="remember-me">Remember me</label>
                              <button type="submit" class="btn" name="reg_user">User/Admin Sign in</button>
                              <a href="register.php" style="text-decoration: none;font-family: 'Antic'"><legend style="position: center;top: 160px;left: 27%;font-size: 18px;height: 30px;color: #ffffff;">Don't have an account? Sign up now!</legend></a>
                        </form>
                    <form role="form" action="userInfoUpdate/processForgotPassword.php" method="post" class="registration-form">
                              <legend style="position: center;top: 160px;left: 27%;font-size: 18px;height: 30px;color: #ffffff;">Forgot Password? Enter your email address</legend>
                              <input type="text" style="width: 100%;" placeholder="Email Address" name="emailForgot"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="example@domainName.topLevelDomainName">
                              <button type="submit" class="btn" name="reg_user">Send password</button>
                    </form>
    
<!-- Javascript -->
<script src="assets/js/jquery-1.11.1.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/jquery.backstretch.min.js"></script>
<script src="assets/js/scripts.js"></script>
</div>          
</head>
<?php
include('footer.php');
?>
</li>
</html>