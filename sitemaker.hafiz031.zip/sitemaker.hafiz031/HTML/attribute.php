<?php
session_start();
 $_SESSION['currentPage']="HTML.overview";
 
 ?>
 <link rel="stylesheet" type="text/css" href="style.css">
<?php
include('header.php');
?>

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Overview</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/blog-post.css" rel="stylesheet">

  </head>

  <body>
    <!-- Page Content -->
    <div class="container">

      <div class="row">

        <!-- Post Content Column -->
        <div class="col-lg-8">

          <!-- Title -->
          <h1 class="mt-4">HTML Attributes</h1>

          <!-- Author -->
        

          <hr>

          <!-- Date/Time -->

          <hr>

          <!-- Preview Image -->
          

          <hr>
          <h2>HTML Attributes</h2>
          <ul>
            <li>All HTML elements can have <b>attributes</b></li>
            <li>Attributes provide <b>additional information</b> about an element</li>
            <li>Attributes are always specified in <b>the start tag</b></li>
            <li>Attributes usually come in name/value pairs like: <b>name=&quot;value&quot;</b></li>
          </ul>
          <!-- Post Content -->
          <p class="lead">
            The href Attribute
</br>
<pre>
</pre>
HTML links are defined with the anchor tag. The link address is specified in the href attribute:

        <!-- Comment -->
            
<img  src="Capture1.JPG" alt="">


<h2>The src Attribute</h2>
<p>HTML images are defined with the <code class="w3-codespan">&lt;img&gt;</code> tag.</p>
<p>The filename of the image source is specified in the <code class="w3-codespan">src</code> attribute:</p>

<img  src="Capture2.JPG" alt="">


<h2>The width and height Attributes</h2>
<p>Images in HTML have a set of <strong>size</strong> attributes, which specifies the width and 
height of the image:</p>

<img  src="Capture3.JPG" alt="">

        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4">

         
          <!-- Side Widget -->
          <div class="card my-4">
            <h5 class="card-header">Concept</h5>
            <div class="card-body">
              HTML attribute is a modifier of an HTML element type. An attribute either modifies the default functionality of an element type or provides functionality to certain element types unable to function correctly without them. In HTML syntax, an attribute is added to an HTML start tag.
            </div>
          </div>

        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
   

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
<?php
$_SESSION['currentPage']="attribute";
include ('comment.php');
include('footer.php'); 
?>
