<style type="text/css">
@import url('https://fonts.googleapis.com/css?family=Antic');
<?php
	session_start();
?>
</style>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>SiteMaker | Home</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Free HTML5 Website Template by FreeHTML5.co" />
<meta name="keywords" content="free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
<meta name="author" content="FreeHTML5.co" />

<meta property="og:title" content=""/>
<meta property="og:image" content=""/>
<meta property="og:url" content=""/>
<meta property="og:site_name" content=""/>
<meta property="og:description" content=""/>
<meta name="twitter:title" content="" />

<meta name="twitter:image" content="" />
<meta name="twitter:url" content="" />
<meta name="twitter:card" content="" />
	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
<link rel="shortcut icon" href="favicon.ico">

<link href="https://fonts.googleapis.com/css?family=Raleway:200,300,400,700" rel="stylesheet">

<!-- Animate.css -->
<link rel="stylesheet" href="styles/animate.css">
<!-- Icomoon Icon Fonts-->
<link rel="stylesheet" href="styles/icomoon.css">
<!-- Bootstrap  -->
<link rel="stylesheet" href="styles/bootstrap.css">
<!-- Flexslider  -->
<link rel="stylesheet" href="styles/flexslider.css">
<!-- Owl Carousel  -->
<link rel="stylesheet" href="styles/owl.carousel.min.css">
<link rel="stylesheet" href="styles/owl.theme.default.min.css">
<!-- Theme style  -->
<link rel="stylesheet" href="styles/style.css">

<!-- Modernizr JS -->
<script src="js/modernizr-2.6.2.min.js"></script>
<link rel="stylesheet" type="text/css" href="styles/styleHeader.css">
<?php
	//$_SESSION['un']=1;
	if($_SESSION['isAdmin']==1)
	{
		echo '
			<body>
			<div id="fh5co-page">
			<header id="fh5co-header" role="banner">
			<div class="container">
			<div class="header-inner">
			<h1><a href="index.html">SiteMaker</a></h1>
			<nav role="navigation">
				<ul>
					<li><a href="..\index.php">Home</a></li>
					<li><a href="..\tutorials.php">Tutorial</a></li>
					<li><a href="..\logout.php">Sign out</a></li>
					<li><a href="..\profile.php">Profile</a></li>
					<li><a href="..\users.php">Manage User</a></li>
				</ul>
			</nav>
			</div>
			</div>
			</header>';
	}
	else
	{
		if(isset($_SESSION['un']))//available for logged in users
		{
		echo '
			<body>
			<div id="fh5co-page">
			<header id="fh5co-header" role="banner">
			<div class="container">
			<div class="header-inner">
			<h1><a href="index.html">SiteMaker</a></h1>
			<nav role="navigation">
				<ul>
					<li><a href="..\index.php">Home</a></li>
					<li><a href="..\tutorials.php">Tutorial</a></li>
					<li><a href="..\logout.php">Sign out</a></li>
					<li><a href="..\profile.php">Profile</a></li>
				</ul>
			</nav>
			</div>
			</div>
			</header>';
		}
		else //available for not-logged in users
		{
			echo'
				<body>
				<div id="fh5co-page">
				<header id="fh5co-header" role="banner">
				<div class="container">
				<div class="header-inner">
				<h1><a href="index.php">SiteMaker</a></h1>
				<nav role="navigation">
					<ul>
						<li><a href="..\index.php">Home</a></li>
						<li><a href="..\tutorials.php">Tutorial</a></li>
						<li><a href="..\login.php">Admin/User Sign in</a></li>
						<li><a href="..\register.php">Sign up</a></li>
					</ul>
				</nav>
				</div>
				</div>
				</header>';
		}	
		}
	
	?>
</nav>

<div id="container"><!--100% height height by defalut-->