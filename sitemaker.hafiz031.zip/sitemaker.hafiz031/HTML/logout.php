<?php
include('mysqlConnect.php');
session_start();
if(isset($_SESSION['un'])&&isset($_SESSION['pw']))
{
	//we need the session actually running here before we can destroy it
    session_unset();
    session_destroy();
    //echo "<script>window.open('../index.php',_self)</script>";
//echo "<script type='text/javascript'>window.open('index.php','_self')</script>";
exit();
}

