<?php
$recipientAddress=$_SESSION['ra'];
$mailBody=$_SESSION['mailBody'];
require_once('PHPMailer/PHPMailerAutoload.php');
$mail=new PHPMailer();
$mail->isSMTP();
$mail->SMTPAuth=true;
$mail->SMTPSecure="ssl";
$mail->Host='smtp.gmail.com';
$mail->Port='465';
$mail->isHTML();
$mail->Username="hafiz031demo@gmail.com";
$mail->Password='$aph123#';
$mail->SetFrom('no-reply@sitemaker.com');
$mail->Subject='Hello! This is your password (Sitemaker)';
$mail->Body="Your Password: ".$mailBody;
$mail->AddAddress($recipientAddress);
$mail->Send();
?>