<?php
session_start();
 include('includes/header.php');
$arr = explode("?",  $_SERVER['REQUEST_URI'], 2);
$first = $arr[1];
$arr1 = explode("=",$first, 2);
$unm=$arr1[0];
//$what_you_want = substr($_SERVER['REQUEST_URI'], 0, strpos($str, '?'));
//echo $what_you_want;
?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<link rel="stylesheet" type="text/css" href="styles/style.css">
<div class="container">
    <div class="row profile">
		<div class="col-md-3">
			<div class="profile-sidebar">
				<!-- SIDEBAR USERPIC -->
				<div class="profile-userpic">
				<?php
				include('mysqlcon/mysqlConnect.php');
				mysql_select_db("SitemakerDB",$con);
				$uname=$_SESSION['un'];
				$query="SELECT * FROM registration_info WHERE Username='".$unm."'";
    				$result=mysql_query($query);
    				$row=mysql_fetch_array($result);
    				$loc=substr($row[PPDirectory],3);
				?>
				<img src=<?php echo $loc ?> alt="invalid directory">'
				</div>
				<!-- END SIDEBAR USERPIC -->
				<!-- SIDEBAR USER TITLE -->
				<div class="profile-usertitle">
					<div class="profile-usertitle-name">
						<?php echo $uname;?>
					</div>
				</div>
				<!-- END SIDEBAR USER TITLE -->
				<!-- SIDEBAR BUTTONS 
				<div class="profile-userbuttons">
					<button type="button" class="btn btn-success btn-sm">Follow</button>
					<button type="button" class="btn btn-danger btn-sm">Message</button>
				</div>
				 END SIDEBAR BUTTONS -->
				<!-- SIDEBAR MENU 
				<div class="profile-usermenu">
					<ul class="nav">
						<li class="active">
							<a href="#">
							<i class="glyphicon glyphicon-home"></i>
							Overview </a>
						</li>
						<li>
							<a href="#">
							<i class="glyphicon glyphicon-user"></i>
							Account Settings </a>
						</li>
						<li>
							<a href="#" target="_blank">
							<i class="glyphicon glyphicon-ok"></i>
							Tasks </a>
						</li>
						<li>
							<a href="#">
							<i class="glyphicon glyphicon-flag"></i>
							Help </a>
						</li>
					</ul>
				</div>
				 END MENU -->
			</div>
		</div>
		<div class="col-md-9">
			<!--Trial Starts here-->   
			
		    <meta charset="utf-8">
		    <meta http-equiv="X-UA-Compatible" content="IE=edge">
		    <meta name="viewport" content="width=device-width, initial-scale=1">
		    <title>Bootstrap Login &amp; Register Templates</title>
		    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
		    
		    
		    <link rel="stylesheet" href="assets/css/form-elements.css">
		    <link rel="stylesheet" href="assets/css/style.css">

		    <!-- Favicon and touch icons -->

		<div class="container" style="width: 70%;">

		<div class="row">
		        	<?php
		            $uname=$_SESSION['un'];
		            $fname=$_SESSION['fn'];
		            $lname=$_SESSION['ln'];
		            $em=$_SESSION['em'];
		            ?>
		                <div class="form-bottom" style="width: 700px;">
		                    <form role="form" action="userInfoUpdate/processProfileUpdate.php" method="post" class="registration-form" enctype="multipart/form-data">
		                    	<div class="form-group">
		                            <legend style="color: white;font-size: 15px;">The fields marked with * must be filled</legend>        
		                            <h3 style="color: white;font-size: 15px;width: 1px;">Username*
		                        	 <input style="width: 650px;" type="text" value= "<?php echo htmlspecialchars($uname); ?>" name="username" placeholder="Username*"><!--showing existing values as well--></h3>
		                        </div>
		                        <div class="form-group">
		                        	<h3 style="color: white;font-size: 15px;width: 1px;">Firstname:
		                            <input style="width: 650px;" type="text" value="<?php echo htmlspecialchars($fname); ?>" name="firstname" placeholder="Firstname"></h3>
		                        </div>
		                        <div class="form-group">
		                        	<h3 style="color: white;font-size: 15px;width: 1px;">Lastname:
		                            <input style="width: 650px;" type="text" value="<?php echo htmlspecialchars($lname); ?>" name="lastname" placeholder="Lastname"></h3>
		                        </div>
		                        <div class="form-group">
		                        	<h3 style="color: white;font-size: 15px;width: 650px;">Email:
		                        		<input type="text" style="width: 100%;" placeholder="Email" name="email"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="example@domainName.topLevelDomainName">
		                            
		                        </div>
		                         <div class="form-group">
		                        	<h3 style="color: white;font-size: 15px;">Old Password:<br>
		                            <input style="width: 650px;" type="text" name="oldpassword" autocomplete="off" placeholder="Old Password*"></h3>
		                        </div>
		                        <div class="form-group">
		                        <h3 style="color: white;font-size: 15px;">New Password:<br>
		                        <input style="width: 650px;" type="text" name="newpassword" autocomplete="off" placeholder="New Password (Leave if not to change)"></h3>
		                        <!--image change-->
		                         <h5 style="color: #fff;">Change Profile Picture (leave empty if you don't want to change):</h2><input type="file" class="filestyle" name="file" data-classButton="btn btn-primary" data-input="false" data-classIcon="icon-plus" style="color: #fff;">
		                         <!--end of image changing code-->
		                        <button type="submit" class="btn" name="reg_user">Update</button>
		                        <button type="submit" style="margin-top: 10px;background: #145" name="dacc" class="btn" onclick="return confirm('Are you sure you want to delete account (This process cannot be undone)?')">Delete Account</button>
		                    </form>
		                </div>
		        	</div>
		        	
		    </div>
		    
		</div>
		<!-- Javascript -->
		<script src="assets/js/jquery-1.11.1.min.js"></script>
		<script src="assets/bootstrap/js/bootstrap.min.js"></script>
		<script src="assets/js/jquery.backstretch.min.js"></script>
		<script src="assets/js/scripts.js"></script>

		</body>

		</html>
            </div>
		</div>
	</div>
</div>
<br>
<br>
<?php
include('includes/footer.php');
?>