<?php
 include('includes/header.php');
?>
<li style="background-image: url(images/long_way_to_go.jpg);
    height: 700px;
    background-size: cover;
    background-size: 100% 100%;
    background-repeat: no-repeat;
    background-position: right top;
    background-attachment: fixed;"
>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap Login &amp; Register Templates</title>
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Favicon and touch icons -->
    <link rel="shortcut icon" href="assets/ico/favicon.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
	
        	<div class="form-box">
        		<div class="form-top">
            		<div class="form-top-left">
            			<h3>Sign up now</h3>
                		<p>Fill in the form below to get instant access:</p>
            		</div>
            		<div class="form-top-right">
            			<i class="fa fa-pencil"></i>
            		</div>
                </div>
                <div class="form-bottom">
                    <form role="form" action="userInfoUpdate/processReg.php" method="post" class="registration-form" enctype="multipart/form-data">
                    	<div class="form-group">
                    		<label class="sr-only" for="form-first-name">Username</label>
                        	 <input type="text" style="width: 100%;" placeholder="Username" name="username" class="grad">
                        </div>
                        <div class="form-group">
                        	<label class="sr-only" for="form-last-name">First Name</label>
                        	<input type="text" style="width: 100%;" placeholder="First Name" name="firstname">
                        </div>
                        <div class="form-group">
                        	<label class="sr-only" for="form-last-name">Last Name</label>
                        	<input type="text" style="width: 100%;" placeholder="Last Name" name="lastname">
                        </div>
                        <div class="form-group">
                        	<label class="sr-only" for="form-email">Email</label>
                        	  <input type="text" style="width: 100%;" placeholder="Email" name="email"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="example@domainName.topLevelDomainName">
                        </div>
                         <div class="form-group">
                        	<label class="sr-only">Password</label>
                        	  <input type="password" style="width: 100%;" placeholder="Password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
                        </div>
                        <div class="form-group">
                            <label class="sr-only">Password</label>
                              <input type="password" style="width: 100%;" placeholder="Confirm Password" name="cpassword" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
                        </div>
                        <div>
                         <!--<input type="file" name="uploadImage" style="padding-left:5px;height:40px;width:240px;border-radius:5px;color: #fff;" required>-->
                         <h5 style="color: #fff;">Select Image:</h2><input type="file" class="filestyle" name="file" data-classButton="btn btn-primary" data-input="false" data-classIcon="icon-plus" style="color: #fff;" required>
                     </div>
                        <button type="submit" class="btn">Sign up</button>
                    </form>
<!-- Javascript -->
<script src="assets/js/jquery-1.11.1.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/jquery.backstretch.min.js"></script>
<script src="assets/js/scripts.js"></script>
</div>          
</head>
<?php
include('includes/footer.php');
?>
</li>
</html>